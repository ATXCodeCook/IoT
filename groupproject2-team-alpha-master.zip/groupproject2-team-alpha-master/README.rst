Group Project 2: Team Alpha, ACC COSC2325 Fall 2016
+++++++++++++++++++++++++++++++++++++++++++++++++++
Range Finder for the arduino using assembly

To upload code to arduino: Run script by typing ./mkl(short for "make load") in the aRangeFinder directory. it includes make, make clean, change directory and make load commands.

First commit: Uploading project structure to provide all members with access. Code under construction. It uploads to arduino succesfully.

Second commit: Changed project to: Two LED's now blink depending on the distance sensed by the ultrasonic sensor. Blue blinks for each foot,then red blinks for each inch. Both blink at every sensing cycle. 

Third commit: Changed some special register file names.

Fourth commit: Added fritzing image.


